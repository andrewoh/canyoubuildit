# Does San Francisco have an unusual second-half injury pattern?

## Answer for the article

**The public play-by-play evidence does not show a special second-half skew for San Francisco.** Across the 2017–2025 regular seasons, 55.9% of the 49ers’ first recorded on-play injury announcements occurred after halftime, compared with 59.1% for everyone else. The difference is −3.2 percentage points, with a game-bootstrap 95% interval from −8.7 to +2.2 points. San Francisco ranks 23rd of 32 franchises by its second-half share. Its fourth-quarter share is essentially identical to the rest of the league: 32.2% versus 32.2%.

This is a **proxy analysis of explicitly recorded on-play injury announcements**, not a census of clinical injuries. It cannot divide the report’s AGL burden into first- and second-half injuries. AGL includes absences originating in practices, previous games, offseason injuries, and other situations without a current-game injury timestamp. The play-by-play announcements also include players who quickly return, whereas a season-ending injury and a brief stoppage each count once here.

The original workload importance result does not predict a particular half: it concerned exposure in **previous games**, not cumulative snaps earlier in the same game. A player with substantial recent playing time might be hurt on the opening play. A second-half skew is a new empirical hypothesis, not an implication of that model.

Suggested concise chart headline: **“A late-game pattern, but not a special 49ers pattern.”**

Suggested precise chart subtitle: **“First explicit on-play injury announcements per player-game, regular season 2017–2025. Overtime excluded from the half shares.”**

## Main descriptive result

| Group | First half (Q1–Q2) | Second half (Q3–Q4) | Second-half share | Game-bootstrap 95% CI |
|---|---:|---:|---:|---:|
| 49ers | 126 | 160 | 55.94% | 50.61%–61.30% |
| Other 31 franchises | 2,907 | 4,209 | 59.15% | 58.00%–60.27% |
| SF minus others | — | — | −3.20 percentage points | −8.69 to +2.20 points |

There is one additional SF announcement in overtime and 51 for other teams, kept separate. Total cohort: 7,454 first announcements per player-game, including overtime, from 2,383 regular-season games. San Francisco played 149 of those games. First-half/second-half comparisons use 286 SF and 7,116 other regulation announcements.

| Quarter | SF announcements | SF share of regulation | Other announcements | Other share of regulation |
|---|---:|---:|---:|---:|
| Q1 | 53 | 18.53% | 1,116 | 15.68% |
| Q2 | 73 | 25.52% | 1,791 | 25.17% |
| Q3 | 68 | 23.78% | 1,916 | 26.93% |
| Q4 | 92 | 32.17% | 2,293 | 32.22% |

**2024 alone runs against the proposed story:** 16 SF first-half versus 13 second-half announcements (44.8% second half). This is just 29 announcements and does not fully represent the major absences that made the season so damaging. Annual values are available in `season_half_shares.csv`; small yearly samples should not be treated as stable tendencies.

## Exposure check

A higher share after halftime might simply reflect more plays. As a secondary check, the denominator counts each team’s recorded game-play opportunities within each half, including penalty/no-play records and special teams, but excluding timeouts and administrative events. This is **not an exact count of actual snaps or player exposures**: some penalty rows are pre-snap, and personnel differ across play types. Label it “per 1,000 recorded play opportunities,” not “per 1,000 player snaps.”

| Group | First-half announcements / 1,000 opportunities | Second half | Second/first ratio (95% CI) |
|---|---:|---:|---:|
| SF | 10.61 | 13.47 | 1.27 (1.03–1.58) |
| Others | 7.78 | 11.29 | 1.45 (1.38–1.52) |

The ratio comparing those two within-game increases is **0.876 (95% CI 0.704–1.093)**. Thus, adjusting approximately for the number of recorded play opportunities does not reveal a larger SF second-half increase. SF has higher recorded announcement rates in both halves, but the extra second-half concentration is not greater.

If chart space is tight, lead with the distribution and confidence interval; put this denominator check in expandable methods rather than presenting the approximation as clinical incidence.

## Extraction definition and audit

1. Download complete nflverse play-by-play parquet files for 2017–2025, then select the relevant identifiers, descriptions, quarters, clocks, teams, and play types. Full raw snapshots, selective-column snapshots, URLs, release timestamps, and SHA-256 hashes are retained locally.
2. Restrict to `season_type == REG`. Completed-game coverage is 256 games/year in 2017–2020, 272 in 2021 and 2023–2025, and 271 in 2022. The cancelled BUF–CIN game does not appear in this completed-game cohort.
3. Select the specific phrase “TEAM-jersey-player was injured during the play.” Identify the injured team from that clause, never from the offense or the last player named in the underlying football action. Both players are counted when one play identifies injuries to opposing teams.
4. Normalize relocated franchise codes (LA/STL→LAR, OAK→LV, SD→LAC). Validate every identified team against the two game participants; this snapshot has **zero invalid-team tokens**.
5. Remove repeated copies of the same player’s injury clause within a single play (23 duplicate tokens), which can arise around replay/reversed-play descriptions.
6. Primary cohort retains only the first such announcement for each game/team/jersey. This avoids treating repeated mentions or re-injury announcements as independent first events. It removes 185 later player-game announcements. A sensitivity analysis retains all unique player-play announcements.
7. Use the associated play’s quarter for timing: Q1+Q2 first half; Q3+Q4 second; Q5 overtime separately. The play clock is a timestamp for the recorded play, not a medically adjudicated injury-onset second.
8. Exclude return-to-play updates, halftime/status announcements, generic injury timeouts, referee injuries, and unstructured descriptions without the required explicit on-play clause. Those records cannot safely timestamp a new injury in the associated quarter.

**Audit results:** 9,012 play-by-play rows mention an injury-related word. There are 7,480 rows with the standardized initial clause, containing 7,662 player tokens, 7,639 unique player-play announcements, and 7,454 first player-game announcements. Excluded noninitial rows: 1,412 injury-update rows, 86 timeout rows, and 34 other nonstandard/nonspecific rows. Some rows contain an initial announcement plus a separate update and remain eligible for the initial announcement only.

All 7,662 standardized clauses are matched. An independent parser checked the nearest explicit team/jersey token preceding each clause, yielding **zero attribution disagreements**. This matters: an early permissive draft incorrectly crossed sentence boundaries after a punt’s “downed by” player. The error was caught in the manual audit and fixed before these final results. Current name matching allows initials, hyphenated names, suffixes, and spaced surnames such as “Van Noy” and “St. Brown,” but cannot cross a jersey number into a preceding player’s text.

A seeded 72-row sample (eight per season) was reviewed against source descriptions. All spaced player-name forms were also reviewed. The 34 nonstandard/nonspecific exclusions were examined, including some real injury/status reports whose timing could not be assigned reliably. A few explicit nonstandard on-play descriptions are omitted by this conservative definition; they remain visible in `excluded_mentions.csv`. No bespoke additions were made to favor a team or half.

Examples illustrating the data structure:

- `2017_01_CAR_SF`: Q1 reports Reuben Foster’s injury; Q3 Kyle Juszczyk’s; Q4 Eli Harold’s.
- `2024_02_SF_MIN`: one Q3 play explicitly reports injuries to both Justin Jefferson (MIN) and Nick Bosa (SF), which must be attributed separately.
- `2024_01_NYJ_SF`: a Q3 record says Jauan Jennings has returned; no standardized initial on-play announcement exists for him in that game. Counting the return as a new Q3 injury would be wrong.
- `2019_11_ARI_SF`: an injury reference concerns a down judge and is excluded.

## Demonstrated missingness and reporting bias

The dataset is not complete injury surveillance. In the standardized 2024 return-update format, **119 of 609 distinct returning-player games** have no corresponding initial on-play announcement anywhere in that game. In 2025, it is **114 of 631**. These are direct examples of unobserved initial events, not an estimate of total sensitivity: they concern the selected subset that generated a parseable return update. Another small set has its first explicit initial announcement after the first return update, suggesting multiple episodes or an earlier missing event.

The standardized return-update format is concentrated in 2024–2025; zero parsed return updates in earlier years means that particular format is absent, not that nobody returned from injuries. Injury-update wording varies by scorer and venue in earlier years. Generic timeout and injury-status text is not consistently recorded and is particularly affected by end-of-half clock procedures. Even the explicit-on-play cohort may favor conspicuous stoppages over players who quietly leave the field. The half distribution can reflect game state, play type, collision exposure, reporting, and availability of players—not just fatigue.

The audit finds at least one initial announcement in 2,228 of 2,383 league games. A game without an announcement is not proof of a game without injuries. SF has at least one in 127 of 149 games. Full season-by-season counts, omissions, and return-update diagnostics are in `coverage_by_season.csv`.

This analysis cannot establish whether practice design, conditioning, fatigue, turf, or medical decisions caused any pattern. It also does not link a particular recorded event to a later absence or its severity.

## Sensitivity checks

The directional conclusion is unchanged:

| Alternative definition | SF second-half share | Others | SF minus others |
|---|---:|---:|---:|
| All unique player-play announcements (include later recurrences) | 56.46% | 59.82% | −3.36 points |
| Exclude the final two minutes of Q2 and Q4 | 58.69% | 61.35% | −2.67 points |
| Completed scrimmage play types only (pass/run/kneel/spike) | 56.86% | 59.85% | −2.98 points |
| 2017–2020 only | 57.75% | 59.92% | −2.17 points |
| 2021–2025 only | 54.17% | 58.63% | −4.46 points |

The end-of-half exclusion is a reporting-rule sensitivity; it is not a cure for missing or inconsistently recorded injuries. These checks are descriptive, and no isolated subgroup is promoted as a new discovery.

## Uncertainty

The primary comparison uses 10,000 bootstrap draws of entire games, stratified by season and whether SF played, with seed 260926. Injury events within the same game remain together; opponent events in SF games are resampled jointly. Stratification preserves the observed season mix and SF game count. Reported 95% intervals are bootstrap percentiles. They capture variation among observed games, not bias from unrecorded injuries or scorer conventions. Team ranking is descriptive; the rank is not a significance test or a stable biological trait.

## Source and reproducibility

Primary documentation:
- nflreadr loader and source repository: https://nflreadr.nflverse.com/reference/load_pbp.html
- Play-by-play field dictionary: https://nflreadr.nflverse.com/articles/dictionary_pbp.html
- Data release: https://github.com/nflverse/nflverse-data/releases/tag/pbp
- Underlying loader source: https://github.com/nflverse/nflreadr/blob/main/R/load_pbp.R

Run `analyze.py` against the nine frozen `data/selected_2017.parquet` through `data/selected_2025.parquet` snapshots with Python, pandas, numpy, and pyarrow. No network request is needed to reproduce the analysis. `acquire.py` is an optional source-refresh step and may retrieve subsequently revised data; do not use it to overwrite the frozen baseline when checking reproducibility. `provenance.json` records source URLs, raw and selected-snapshot SHA-256 hashes, file sizes, release timestamps, and selected columns. No individual snap or health-tracking data is inferred from the descriptions.

Chart-ready outputs:
- `half_comparison.csv`: counts, shares, and approximate per-opportunity rates.
- `quarter_comparison.csv`: Q1–Q4 plus separate overtime counts and exposure.
- `team_half_shares.csv`: all 32 teams, sample sizes, game-bootstrap intervals, descriptive rank.
- `season_half_shares.csv`: annual SF-versus-other counts and shares.
- `results.json`: final estimates, paired uncertainty, sensitivities, parser audit, coverage.

Audit/reproduction outputs:
- `first_events.csv`: the exact primary event cohort, with original descriptions.
- `initial_events_all.csv`: unique player-play injury announcements, with first-event marker.
- `excluded_mentions.csv`: every excluded injury-related row and its reason.
- `return_update_audit.csv`: explicit evidence of missing onsets.
- `multi_player_plays.csv`, `audit_sample.csv`, and `invalid_team_events.csv`.
- `game_quarter_counts.csv`, `game_quarter_exposure.csv`, and `coverage_by_season.csv`.


## Interactive chart filters

`build_chart_data.py` reads the frozen `game_quarter_counts.csv` produced by the analysis and writes `timing-data.json` (about 148 KB) plus a flat `team_period_comparisons.csv` (384 rows). Each of the 32 franchises can be compared with the other 31 for the full 2017–2025 era, 2017–2020, 2021–2025, or one of the nine individual seasons.

Each filter uses whole-game bootstrap resampling stratified by season and whether the selected team participated, preserving opponent events within the same game. The primary full-era SF filter retains the published 10,000-draw intervals; the other filters use 5,000 draws with seed 290926. At most two of 5,000 draws in the sparsest filters contain no selected-team announcements, leaving their share undefined; these draws are excluded from percentile calculations, and the nonempty-draw count is recorded. The smallest observed annual sample is nine announcements, so the chart flags small annual cohorts and shows their wide intervals. These exploratory filters are not independent preregistered tests.

The chart uses distributions rather than approximate play-opportunity rates, to avoid implying that the publicly recorded game-play denominator is a precise count of individual player exposures. Its SVG and PNG exports include the selected team/period, explicit proxy definition, color legend, interval meaning, and source footer.
