# Injury-report body-region mix, 2017–2025

## What this answers

San Francisco's **reported mix** tilts toward knees and calf/Achilles conditions. Knees account for 23.9% of its physical injury/condition listing weight, against a season- and position-standardized 18.9% for the other 31 teams: a **5.0 percentage-point gap**. Calf/Achilles is 6.8% versus 4.1%, a **2.7-point gap**. Hamstrings are lower, 8.2% versus 9.9%; this does not support a blanket claim that every soft-tissue category is elevated.

The direction survives age adjustment and reduced-repeat sensitivities. Knee is above its position-adjusted comparator in each of the nine seasons, whereas calf/Achilles varies substantially by year. These are suggestive descriptive patterns. **No category's approximate simultaneous 95% interval excludes zero.** Neither the knee pattern nor the calf/Achilles pattern establishes a distinct causal injury syndrome, more ACL tears, or more Achilles ruptures.

## The endpoint and denominator

This is the composition of **physical injury/condition mentions in public regular-season injury/practice reports**, conditional on a player being listed. It is not clinical injury incidence, a count of unique injuries, missed games, AGL, or a population injury risk. A player appearing in ten weekly reports contributes ten player-game listings in the primary analysis. The measure can therefore reflect duration, reporting conventions, and follow-up as well as frequency.

Each physical player-game listing contributes exactly one unit. Its weight is split equally across its distinct body-region categories. A knee-and-ankle listing contributes 0.5 to each; knee appearing in multiple fields is counted once. Thus all 11 shares sum to 100%. Fractional counts are expected and must not be presented as integer counts of injuries.

The classification pools `report_primary_injury`, `report_secondary_injury`, `practice_primary_injury`, and `practice_secondary_injury`. It retains an anatomical/physical condition if another field or clause also mentions illness/rest. COVID, illness, non-injury rest, personal reasons, and administrative entries alone are excluded. Vague `Other`/`Medical` alone is excluded rather than guessed. `Other physical condition` contains specified remaining physical conditions, including ribs, pectoral, quadriceps/thigh, abdomen, organs, dental/head complaints, and heat/dehydration. “Concussion-related” includes reports mentioning evaluation, clearance or protocol; a mention is not necessarily a confirmed concussion. A headache alone is not labeled concussion.

These public reports omit important direct-to-injured-reserve cases and do not reliably specify pathology. “Knee” cannot distinguish an ACL tear from soreness. “Achilles” cannot establish a rupture. Do not frame this as a breakdown of all injuries sustained by the team.

## Coverage and audit

- Seasons: 2017–2025, regular season only. No partial 2026 data.
- 48,512 source rows; 48,510 after deduplication; 48,493 matched to completed games. The 17 unmatched/unplayed-game rows are excluded.
- 41,531 physical player-game listings: **1,354 SF**, **40,177 other teams**.
- 2,479 multi-category listings, including 125 SF listings.
- 254 distinct nonblank source phrases reviewed; no unmapped phrase occurrences remain. The full decision log is `classification_audit.csv`.
- 3,396 listings fall exclusively under the specified `Other physical condition` bucket, including 115 SF listings.
- 19 physical listings contain concussion evaluation/protocol/clearance wording.
- Zero physical listings have missing age after metadata linkage. Eleven have unknown position; none are SF.
- Reports cover 4,759 of 4,766 completed team-games. The seven missing team-games are enumerated in `results.json`; they are not assumed to be healthy. SF covers all 149 games.
- The source snapshots and SHA-256 hashes are recorded in `results.json`.

## Standardization and uncertainty

For the primary comparison, other-team category shares are calculated within **season × broad listed-position** strata. They are then weighted to the distribution of SF's physical-report listings across those strata. This asks: “What mix would the other teams have with SF's calendar and listed-position composition?” It does **not** estimate risk per roster player or playing exposure. Because SF is the reference population, this is an SF-standardized comparison, not a universal league average.

Broad positions are OL, DL, LB, DB, RB (including FB), WR, TE, QB, specialists, and unknown. Listed position can imperfectly distinguish edge defenders. An additional sensitivity includes age bands below 25, 25–28, and 29+.

The primary full-era SF comparison uses 4,000 bootstrap repetitions, seed 260926. It resamples 181 SF player trajectories across all their observed seasons, and independently resamples the 31 other franchises across all their seasons. This preserves repeated weekly listings by the same SF player and reference-franchise dependence. Each replicate recomputes SF stratum weights and comparison rates. No empty-reference-stratum fallback was needed.

`pointwise_lo_pp` / `pointwise_hi_pp` are nominal 95% percentile intervals for individual categories. `simultaneous_lo_pp` / `simultaneous_hi_pp` are approximate 95% intervals for the entire 11-category family, using the bootstrap's maximum standardized deviation. **Use simultaneous intervals as the default chart whiskers.** The exploratory global maximum-statistic bootstrap p-value is 0.0895. It is conditional on this selected team and period, not a confirmatory test: this is one SF organization; shared calendar shocks and player movement across teams are not fully modeled; SF and the window were selected after seeing its history.

No naive independent-row chi-square p-value is used. The included Cramér's V (0.043) is descriptive only; it is sensitive to the unequal group sizes and is not the main interpretation. Adjusted total variation is 0.100: about ten percentage points of composition mass separate the two distributions. Neither statistic is an estimate of extra injuries or causal effect.

## Sensitivity checks

All use the same fractional-listing approach and season/position adjustment unless noted. These are descriptive point estimates, not additional confirmatory tests.

| Definition | Knee gap (pp) | Calf/Achilles gap (pp) |
|---|---:|---:|
| Primary weekly listing mix | +4.98 | +2.68 |
| Add age-band adjustment | +5.15 | +2.74 |
| First region listing or ≥28-day gap | +4.54 | +1.86 |
| First region within player-season | +4.14 | +1.87 |
| Exclude 2020 and 2021 | +5.59 | +1.74 |
| 2022–2025 only | +6.42 | +1.86 |
| Out or Doubtful reports only | +7.07 | +4.31 |

The 28-day rule marks the first observed listing for a player/region or a listing at least 28 days after the preceding same-region listing. It resets over an offseason and can identify either a new problem or recurrence/continuation. It is a **newly observed region-listing proxy**, not an incident-injury adjudication. If a report introduces multiple qualifying regions, its one unit is divided among those new regions. The denominator is 673 SF qualifying reports and 20,198 elsewhere. First-region-within-player-season similarly limits repeat mentions of a location within a season; its denominator is 612 SF qualifying reports and 18,598 elsewhere. Neither gives each player equal weight.

Out/Doubtful is a report-status sensitivity, not a verified inactive or missed-game endpoint. Removing pandemic seasons addresses calendar sensitivity; COVID/illness-only reports are already excluded in every analysis.

## Chart integration

`web_data.json` contains browser-ready named records with no player identifiers. `comparisons` has all 32 teams × ten filters (0 = all 2017–2025; otherwise the exact season) × 11 categories. For each selection, `share` is that team's mix and `other_standardized_share` is its own season/position-standardized other-31 comparator. `physical_listing_rows` is the team's denominator, and `fractional_listings` is the category's contribution to it. Shares are fractions; differences and interval bounds are already percentage points.

Recommended main display: selected-team share versus standardized other-31 share, with a second panel of percentage-point differences. Default to SF, 2017–2025 and show simultaneous intervals from `primary.categories`. **Intervals are only available for that primary full-era SF comparison**; hide them and label other team/year selections as descriptive. Do not retain a static SF headline when another team or year is selected.

Use “Share of physical injury/condition report listings” on the share axis and “Difference vs. other 31 teams (percentage points)” on the difference axis. Keep “season/position standardized” visible. In tooltips, say e.g. “323.5 weighted knee listings / 1,354 physical player-game listings.” A share difference is not an incidence-rate difference. `fractional_listings_per_team_game` is an observed report-listing frequency, not an athlete-exposure injury rate; it should not replace the mix endpoint silently.

`team_season_mix.csv` has raw-count/coverage data plus proxy shares. `team_era_mix.csv` pools counts across the full era. `sf_vs_league_adjusted.csv` contains all primary intervals. `mix_sensitivities.csv` contains sensitivity points; `sf_vs_league_by_year.csv` contains annual SF points; `team_comparisons_all_filters.csv` mirrors browser comparisons. Audit files containing GSIS identifiers are for reproducibility, not chart payloads.

## Sources and reproduction

Sources are the existing frozen [nflverse public injury reports](https://github.com/nflverse/nflverse-data/releases/tag/injuries), [NFL schedule/game data](https://github.com/nflverse/nfldata/blob/master/data/games.csv), and [player metadata](https://github.com/nflverse/nflverse-data/releases/tag/players). These are public reporting data, not the league's clinical electronic medical records.

From the project root, run `python work/revision/injury_mix/analyze.py`, then `python work/revision/injury_mix/build_web_data.py`. Required packages are pandas, NumPy and SciPy. The analysis uses local `work/data/injuries_2017.csv` through `injuries_2025.csv`, `games.csv` and `players.csv`; it performs no network downloads. The analysis records dependency versions and source hashes. The web builder checks composition sums, team/year coverage, primary agreement, and CI consistency before writing the display payload.
