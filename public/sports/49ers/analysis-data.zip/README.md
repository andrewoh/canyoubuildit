# Website data schema

Research cutoff: **September 26, 2026**. Statistical comparisons use completed 2017–2025 seasons; partial 2026 data are excluded.

`site-data.json` is a compact, chart-ready consolidation of existing analyses. It contains no `NaN` or infinity values; missing values are `null`. Numbers retain seven decimal places where relevant. All team codes use canonical franchise identifiers (`LAR`, `LAC`, `LV`, `JAX`). Full names are in `teams`.

Two additional payloads extend the article: `injury_mix/web_data.json` for body-region report composition and `injury_timing/timing-data.json` for explicitly recorded in-game announcements. Their endpoints differ from AGL and from the next-report prediction model. Do not join their counts as if they measured the same injuries.

## Common conventions

- **Injury index = 100 × team AGL / same-season NFL mean.** Higher means greater injury burden. An index of 140 means 40% above that season's league average.
- `season` means the injury/outcome season. A profile's `feature_season` and a playoff row's `exposure_season` refer to earlier observed seasons.
- All fields named `index` or containing `_index` use the 100-point scale. Explicitly named `relative`/`relative_burden`/`sf_relative` fields inherited in benchmark details remain ratios (1 = average). Proportions such as `run_share`, win percentage, and membership stability are 0–1 unless the key explicitly says `pct`.
- `rank_healthiest`: 1 is healthiest. `rank_most_injured` and era `rank`: 1 is most injured. Keep their direction clear in charts.
- Analysis is observational; predictive importance and clustering attribution are not injury causes.

## Top-level objects

| Key | Contents |
|---|---|
| `meta` | Coverage, units and caveats. Complete seasons through 2025; partial 2026 excluded from these comparisons. |
| `teams` | 32 `{code, name}` records. |
| `agl` | Annual injury burden, era rankings, SF highlights and sensitivity checks. |
| `playoffs` | Previous-season playoff exposure versus subsequent injury burden. |
| `profiles` | Outcome-independent roster/workload clustering and full-dimensional nearest-neighbor data. |
| `report_model` | Original individual next-report prediction model, validation and held-out permutation importance. |
| `sources` | Exact annual AGL source/archive links, data releases, methods and previously collected research URLs. |

## `agl`

- `rows`: **288** records with `season`, `team`, `agl`, `index`, `rank_healthiest`, optional `off_agl`/`def_agl`, and `source_id`. Source IDs index `sources.agl_annual` (zero based).
- `era`: **32** records, sorted most injured first. `index` is the equal-weight mean of nine annual indexes, not the ratio of total AGL to pooled total. Includes `rank_most_injured`, `agl_total`, `mean_agl_per_game`, `bottom11_seasons`.
- `league_by_year`: nine year-level mean AGL values and mean AGL per scheduled game.
- `sf_highlights`: original benchmark details plus display-ready `sf_index`, `sf_index_boot_ci`, `above_league_percent`. Preserve the distinction between SF ranking first and meeting a formal outlier criterion; `tukey_outlier` is false.
- `sensitivity`: `{analysis, index, rank, years}` records. This field's `index` uses 100 as league average.

## `playoffs`

- `depth_summary`: five ordered categories, with `n`, prior-season and following-season mean injury indexes, change, and following-season mean bootstrap limits (`mean_lo`, `mean_hi`). These are group-mean uncertainty, not predictive intervals for a team.
- `super_bowl_followups`: **16** rows from seven franchises, sorted most injured first. Each has `exposure_season`, outcome `season`, prior/next AGL and index, change, and exposure attributes. Use these to draw individual paired rows or a dot plot.
- `super_bowl_summary`: group counts and prior, next, change, and excluding-SF means.
- `three_straight_conference_followups`: eight descriptive rows from three franchises.
- `primary_effects`: six headline regression effects. `coef`, `lo`, `hi` are **injury-index points per exposure unit**, not percentage-point changes in injury probability. `prior_plays_1000` is per 1,000 offensive-plus-defensive **player snaps**, including playoffs. `prior_post_games` is per playoff game. `prior_sb` contrasts a Super Bowl appearance with all other teams.
- `models`: all **32** model specifications, including adjustment stages and sensitivity checks. Each has `terms`, `n`, `clusters`, `r2`, `outcome`, `team_fe`, and optional restricted wild-cluster bootstrap results. A model whose `outcome` is `agl` reports raw AGL units; do not label those coefficients injury-index points.
- `sf_transitions`: eight SF lagged-season comparisons.

## `profiles`

- `feature_order`: canonical order of the six attributes. The same order applies to every vector below.
- `feature_definitions`: display labels, units, precision and operational definitions. Continuity is historical within-feature-season continuity, **not** retention onto the outcome-season roster.
- `scaler_mean`, `scaler_sd`: pooled 256-row means and population standard deviations. Standardized value = `(raw - mean) / sd`.
- `rows`: **256** objects containing `season`, `feature_season`, `team`, `cluster` (0 or 1), `raw_features` (keyed object), `standardized_features` (six-element vector), `pca` (two-element vector), outcome `index`, `agl`, `membership_stability`, prior win percentage, and prior playoff games.
- `centroids`: two records with label, count, six raw means, six standardized means, outcome index and conditional bootstrap index interval.
- **Nearest-neighbor distance:** Euclidean distance between all six `standardized_features`. For same-year comparisons, first filter `season`; exclude the selected franchise if the intent is external peers. Do not use PCA distances. Verified SF 2024 peers: BUF, KC, CIN, DAL, PHI.
- `pca_explained_variance`: two fractions summing to **0.5344**. The two-dimensional plot omits nearly half of feature variation.
- `k_diagnostics`, `robustness`: separation and stability checks. Primary silhouette is **0.181**; do not illustrate distinct separated islands or imply a definitive taxonomy.
- `burden_difference`: established-contender minus less-established **injury-index points**, with bootstrap and year-adjusted intervals. Negative means less burden. This difference is not statistically clear.
- `separation_attribution`: descriptive shares of between-cluster separation. **Not** injury-risk importance or fractions of injuries explained.
- `sf2024_feature_percentiles` and `sf2024_sameyear_peers`: supplemental chart-ready SF context.

## `report_model`

Training 2017–2022, validation 2023, refit 2017–2023, held-out test 2024–2025. The target is a new public physical-condition/injury report before the next game, **not total medical injury burden**. Direct-to-IR and nonparticipating players can be missed.

- `importance`: eight feature groups. Use `ap_drop_points` and `ap_bootstrap_ci_points` for the main bars. These are drops in average precision ×100. `ap_drop_q025/q975` are permutation variability, not population confidence limits; use the explicitly named bootstrap intervals when displaying uncertainty.
- `relative_positive_importance_pct` is share of positive predictive importance, **not share of injuries caused/explained**.
- `test`, `test_baseline`, `validation`, `test_by_year`, `cluster_bootstrap_95pct`, `calibration`: validation results. AUC and average precision remain 0–1.
- Weekly `Earlier snap workload` importance must not be interpreted as prior-year cumulative exposure. The separate `playoffs` analysis answers the latter question.

## CSV bundle and generation

The published `analysis-data.zip` preserves all **19 core CSVs** from `site-data-csv.zip` and this schema. It includes the full 256-row playoff transition panel, 256 profile rows with six raw and standardized features, annual AGL, 32 era rankings, all regression coefficients, clustering diagnostics, model validation/importance/calibration and source URLs. CSV fields named `relative_burden` remain ratios; their names are preserved from the research tables. Additional aggregate tables and their analysis-specific definitions appear under `injury_mix/` and `injury_timing/`; namespacing preserves every original table.

`build_site_data.py` rebuilds the core `site-data.json` and base CSV archive from existing files. Assertions validate data cardinalities, headline results, and full-vector nearest neighbors. Core JSON serialization rejects nonfinite numbers, and its output is constrained below 400 KB. `build_web_assets.py` packages the published downloads and extends the base archive with the two new analyses; that asset-packaging script requires the local website workspace and is not necessary to reproduce the statistics. The analysis reproduction sequence is in the root README of `reproducibility.zip`.

## Body-region / condition report mix

The endpoint is **physical injury/condition mentions in public regular-season player-game reports**, conditional on being listed. It is not injury incidence, a count of unique injuries, time lost, or diagnoses of ACL tears/Achilles ruptures. All four report/practice primary/secondary fields are considered. Illness/COVID and non-injury-only listings are excluded. Direct-to-injured-reserve cases can be absent.

One physical listing contributes one unit, split equally among its distinct categories. A knee-and-ankle listing contributes 0.5 to each. Repeated weeks contribute repeatedly. The 11 shares sum to 100%; fractional category counts must not be called numbers of injuries. The full-era denominator is 1,354 SF listings and 40,177 other-team listings.

`injury_mix/web_data.json` contains:

- `comparisons`: **3,520 rows**, all 32 teams × ten season filters × 11 categories. `season_filter=0` means all 2017–2025; otherwise it is an exact season. Comparator shares always exclude the selected team.
- `physical_listing_rows`: the selected team's denominator; `fractional_listings`: that category's contribution; `share`: their ratio, a **0–1 fraction**.
- `other_crude_share`: other-31 pooled share; `other_standardized_share`: their category shares within season × listed-position strata, weighted to the selected team's physical-listing composition. This adjusts the **mix conditional on reporting**, not athlete-exposure risk.
- `adjusted_difference_pp`: selected-team minus standardized comparison, already in **percentage points**. Do not multiply again by 100.
- `played_team_games` and `fractional_listings_per_team_game`: calendar denominator and observed listing frequency, not medical injury incidence per athlete exposure.
- `primary.categories`: full-era SF estimates with `pointwise_lo_pp`/`pointwise_hi_pp` and `simultaneous_lo_pp`/`simultaneous_hi_pp`. Default whiskers use approximate simultaneous 95% intervals across all 11 categories. Pointwise intervals are nominal individual-category 95% intervals. **Only this full-era SF selection has bootstrap intervals**; other team/year comparisons are descriptive.
- `sensitivities`: age adjustment, a ≥28-day same-region gap proxy, first region within player-season, pandemic exclusion, recent seasons, and Out/Doubtful-only reporting.
- `annualCoverage`, `audit`, `sources`, `adjustment`, `inferenceCaveat`, `displayNotes`: explicit denominators, coverage and interpretation.

The primary bootstrap resamples whole SF player trajectories across seasons and other-team franchises across seasons, 4,000 times. It preserves repeated reports but cannot represent independent replications of SF or fully remove reporting bias. All 11 simultaneous intervals include zero. The exploratory global p-value is conditional on the selected team/period; the naive independent-row chi-square p-value is not used.

The new-region proxy marks a first observed region or at least 28 days since the previous same-region listing. It can reflect recurrence or continuation and is not a clinically verified new injury. See `injury_mix/README.md` for exact weighting and sensitivity denominators.

Shareable tables:

| File within `injury_mix/` | Contents |
|---|---|
| `sf_vs_league_adjusted.csv` | Full-era SF comparison and both interval types; 11 rows. |
| `sf_vs_league_by_year.csv` | Annual SF comparison; 99 descriptive rows. |
| `team_comparisons_all_filters.csv` | Every team/year filter and its own other-31 comparison; 3,520 rows. |
| `team_era_mix.csv` | Pooled counts, shares and listing frequency; 352 rows. |
| `team_season_mix.csv` | Every team/season/category, denominator, reporting coverage and proxy shares; 3,168 rows. |
| `mix_sensitivities.csv` | Alternative definitions/adjustments, primarily descriptive point estimates. |

## Timing of explicit in-game announcements

The endpoint is the **first explicit on-play injury announcement for each player in each regular-season game**, extracted conservatively from play-by-play descriptions. Return-to-game updates and generic/nonstandard injury mentions are excluded. A brief stoppage and a season-ending injury each count once. This cannot divide AGL into injury-onset quarters or measure fatigue directly.

Coverage is 7,454 first announcements, including overtime, in 2,383 games. Regulation contains 286 SF and 7,116 other-team announcements. Missing initial announcements are demonstrated by return updates without corresponding initial records; absence of a recorded announcement does not mean no injury occurred.

`injury_timing/timing-data.json` contains `teams`, `periods`, `meta`, and `comparisons[periodKey][teamCode]`. The 12 period filters are all 2017–2025, 2017–2020, 2021–2025, and the nine individual seasons. Each record includes:

- `counts` and `rest_counts`: five integer counts ordered **Q1, Q2, Q3, Q4, overtime**. Overtime is excluded from regulation shares.
- `regulation_events`, `rest_regulation_events`, and `games`: sample-size denominators.
- `second_share`, `rest_second_share`, and corresponding `second_ci`/`rest_second_ci`: **0–1 fractions**, not percentages.
- `difference` and `difference_ci`: selected-team minus other-31 second-half share, also **fractions**. Multiply by 100 to show percentage points. This differs from the injury-mix `_pp` fields, which are already scaled.
- `bootstrap_reps` and `bootstrap_nonempty_reps`: attempted draws and usable draws when a sparse resample contains no qualifying selected-team events.

Intervals use whole-game bootstrap resampling stratified by season and whether the selected team played, jointly retaining opponent events. The primary full-era SF comparison uses 10,000 draws; other interactive filters use 5,000. These are nominal 95% intervals, not simultaneous guarantees over all teams/filters, and do not capture reporting bias. Descriptive ranking is not a significance test.

Shareable tables:

| File within `injury_timing/` | Contents and units |
|---|---|
| `half_comparison.csv` | Full-era SF/other counts, regulation shares, and announcements per 1,000 recorded play opportunities. |
| `quarter_comparison.csv` | Q1–Q4 and separate overtime counts/exposure; shares are 0–1 fractions. |
| `team_half_shares.csv` | All-era franchise counts, share, nominal game-bootstrap interval and descriptive rank. Its per-franchise interval is a separate summary from the jointly stratified comparison intervals in the interactive payload. |
| `team_period_comparisons.csv` | All 384 interactive team/period comparisons, quarter counts, denominators and nominal intervals. Share/difference bounds are fractions; multiply by 100 for percentages/percentage points. This table exactly mirrors the interactive comparison estimates. |
| `season_half_shares.csv` | Annual SF/other half counts and descriptive second-half shares. |
| `coverage_by_season.csv` | Games, parsed announcements, excluded updates and demonstrated missingness. |
| `game_quarter_counts.csv` | All-team game-quarter counts, season/team IDs and approximate exposure denominators; no player names or source descriptions. |

The secondary rate denominator is **recorded team play opportunities**, including penalty/no-play records and special teams, but excluding administrative events. It is not an exact count of actual snaps or individual player exposures. `events_per1000_opportunities` must be labeled “per 1,000 recorded play opportunities,” never “per 1,000 player snaps.” Primary shares require no exposure denominator.

## Frozen inputs and archive size

The reproducibility archive includes the original injury/snap/player/schedule data and the nine **selected-column** PBP snapshots needed by the timing parser. It omits the much larger full `pbp_*.parquet` downloads. `injury_timing/provenance.json` records original and selected hashes, source URLs, release timestamps and retained columns. `injury_mix/results.json` records hashes of its frozen injuries/games/player inputs. Acquisition scripts are provenance tools, not required rerun steps against mutable releases.

Run the new analyses with `injury_mix/analyze.py`, then `injury_mix/build_web_data.py`, and `injury_timing/analyze.py`. Rebuild core chart data with `build_site_data.py` before running `injury_timing/build_chart_data.py`, which reads the resulting team list. All paths here are beneath `work/revision/` in the full archive. Raw parsing/classification audits are included only in the reproducibility download; the shareable table ZIP contains aggregate data and definitions.
